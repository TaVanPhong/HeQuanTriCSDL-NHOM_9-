﻿INSERT INTO PhongBan (TenPhong, MaQuanLy) VALUES (N'Phòng Kinh Doanh', NULL);
INSERT INTO PhongBan (TenPhong, MaQuanLy) VALUES (N'Phòng Kỹ Thuật', 1); -- Giả sử nhân viên có MaNhanVien = 1 là quản lý
INSERT INTO PhongBan (TenPhong, MaQuanLy) VALUES (N'Phòng Hành Chính', 1);
INSERT INTO PhongBan (TenPhong, MaQuanLy) VALUES (N'Phòng Marketing', 2); -- Giả sử nhân viên có MaNhanVien = 2 là quản lý

INSERT INTO NhanVien (TenNhanVien, LaQuanLy, MaPhong) VALUES (N'Nguyễn Văn A', 1, 1); -- Quản lý Phòng Kinh Doanh
INSERT INTO NhanVien (TenNhanVien, LaQuanLy, MaPhong) VALUES (N'Trần Thị B', 0, 1); -- Nhân viên Phòng Kinh Doanh
INSERT INTO NhanVien (TenNhanVien, LaQuanLy, MaPhong) VALUES (N'Lê Văn C', 1, 2); -- Quản lý Phòng Kỹ Thuật
INSERT INTO NhanVien (TenNhanVien, LaQuanLy, MaPhong) VALUES (N'Phạm Văn D', 0, 2); -- Nhân viên Phòng Kỹ Thuật
INSERT INTO NhanVien (TenNhanVien, LaQuanLy, MaPhong) VALUES (N'Nguyễn Thị E', 1, 3); -- Quản lý Phòng Hành Chính
INSERT INTO NhanVien (TenNhanVien, LaQuanLy, MaPhong) VALUES (N'Trần Văn F', 0, 3); -- Nhân viên Phòng Hành Chính
INSERT INTO NhanVien (TenNhanVien, LaQuanLy, MaPhong) VALUES (N'Lê Thị G', 1, 4); -- Quản lý Phòng Marketing
INSERT INTO NhanVien (TenNhanVien, LaQuanLy, MaPhong) VALUES (N'Nguyễn Văn H', 0, 4); -- Nhân viên Phòng Marketing

INSERT INTO DuAn (TenDuAn, MoTa, ThoiGianBatDau, ThoiGianKetThuc) VALUES (N'Dự án A', N'Mô tả dự án A', '2023-01-01', '2023-12-31');
INSERT INTO DuAn (TenDuAn, MoTa, ThoiGianBatDau, ThoiGianKetThuc) VALUES (N'Dự án B', N'Mô tả dự án B', '2023-02-01', '2023-11-30');
INSERT INTO DuAn (TenDuAn, MoTa, ThoiGianBatDau, ThoiGianKetThuc) VALUES (N'Dự án C', N'Mô tả dự án C', '2023-03-01', '2023-10-31');

INSERT INTO NhanVienDuAn (MaNhanVien, MaDuAn) VALUES (1, 1); -- Nguyễn Văn A tham gia Dự án A
INSERT INTO NhanVienDuAn (MaNhanVien, MaDuAn) VALUES (2, 1); -- Trần Thị B tham gia Dự án A
INSERT INTO NhanVienDuAn (MaNhanVien, MaDuAn) VALUES (3, 2); -- Lê Văn C tham gia Dự án B
INSERT INTO NhanVienDuAn (MaNhanVien, MaDuAn) VALUES (4, 2); -- Phạm Văn D tham gia Dự án B
INSERT INTO NhanVienDuAn (MaNhanVien, MaDuAn) VALUES (5, 3); -- Nguyễn Thị E tham gia Dự án C
INSERT INTO NhanVienDuAn (MaNhanVien, MaDuAn) VALUES (6, 3); -- Trần Văn F tham gia Dự án C




